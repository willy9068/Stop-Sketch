// 화면 그리기 — 물방울 무리 시험판 (사용자 결정 2026-10-20). 이미지가 없으면 코드로 그린 임시 모양.
//   카메라 (사용자 결정 2026-10-21): 주인공과 대열만 따라감(기본 줌, 스테이지 camera.zoom). 이탈한 물방울 때문에 줌 아웃하지 않음.
//   마우스 휠이 우선이고 잠시 뒤 기본 줌으로 돌아옴. 화면 위 끝·아래 끝(camera.top/bottom) 밖은 안 보여 줌.
//   화면 밖 물방울은 가장자리 화살표. 글자·UI 크기는 uitext.js (G.T / G.TS). 지우개(왼쪽 흰 영역), 검은 잉크병 정화, 아래 5색 병 선반, 스킵 버튼
var G = G || {};

G.UI = (function () {
  var C = G.DATA.colors, V = G.DATA.view;
  var cam = { x: 0, y: 0, z: 1, manualZ: null, manualMs: 0, inited: false };
  var specks = null;

  function makeSpecks() {
    var rnd = G.makeRng(G.DATA.seed), out = [];
    for (var i = 0; i < 160; i++) out.push({ x: rnd() * 4000, y: rnd() * 720, r: 1 + rnd() * 2 });
    return out;
  }

  // ---- 카메라 ----
  // 따라갈 물방울: 주인공 + 대열(붙는 중 포함). 혼자 걷는(이탈한) 물방울은 빼고 화살표로만 (사용자 결정 2026-10-21)
  function focusBox(game) {
    var list = G.Game.walking(game).filter(function (d) { return d.mode !== 'free'; }), box = null;
    if (!list.length) {                            // 아무도 안 걸으면 잉크병 쪽
      var gx = game.level.goalX, gy = game.level.data.goal.y;
      return { x0: gx - 200, x1: gx + 300, y0: gy - 200, y1: gy, hx: gx, hy: gy - 30 };
    }
    list.forEach(function (d) {
      var p = d.body.position;
      if (!box) box = { x0: p.x, x1: p.x, y0: p.y, y1: p.y };
      box.x0 = Math.min(box.x0, p.x); box.x1 = Math.max(box.x1, p.x);
      box.y0 = Math.min(box.y0, p.y); box.y1 = Math.max(box.y1, p.y);
    });
    var lead = game.hero.state === 'walk' ? game.hero : list[0];
    box.hx = lead.body.position.x; box.hy = lead.body.position.y;
    box.x0 = Math.max(box.x0, game.eraserX);         // 왼쪽은 지우개까지만 (사용자 결정 2026-10-20)
    return box;
  }

  function updateCamera(game, realMs) {
    if (game.status === 'fail' && cam.inited) return;   // 실패하면 그 자리에서 멈춤
    var A = G.DATA.art.camera, box = focusBox(game), LC = game.level.data.camera;
    if (cam.manualMs > 0 && G.Game.scale(game) > 0) cam.manualMs -= realMs || 16;
    if (cam.manualMs <= 0) cam.manualZ = null;
    var base = Math.max(A.minZoom, Math.min(A.maxZoom, LC.zoom));      // 기본 줌 (스테이지마다, 레벨 툴)
    var tz = cam.manualZ != null ? cam.manualZ : G.Rules.fitZoom(box, V, A, base);   // 대열이 길 때만 조금 줄어듦
    // 줌 아웃은 빠르게, 줌 인은 천천히 (사용자 요청 2026-10-20: 화면이 확 바뀌지 않게). 휠 줌은 바로
    var k = cam.manualZ != null ? A.zoomOutEase : (tz > cam.z ? A.zoomInEase : A.zoomOutEase);
    cam.z += (tz - cam.z) * (cam.inited ? Math.min(1, k * (realMs || 16) / 16.7) : 1);
    var vw = V.w / cam.z, vh = V.h / cam.z;
    // 무리 가운데를 보되, 주인공(앞장선 물방울)이 화면 밖으로 나가지 않게 (가운데 ↔ 주인공 중심이 툭 바뀌지 않고 이어짐)
    var room = Math.max(0, vw / 2 - A.margin);
    var cx = Math.max(box.hx - room, Math.min(box.hx + room, (box.x0 + box.x1) / 2));
    var cy = (box.y0 + box.y1) / 2;
    // 땅이 화면 아래쪽에 오게. 화면 아래 끝 밑·위 끝 위는 안 보여 줌 (사이가 화면보다 좁으면 아래 끝에 맞춤)
    var tx = cx - vw / 2, ty = Math.min(cy - vh * 0.72, LC.bottom - vh);
    ty = LC.bottom - LC.top >= vh ? Math.max(ty, LC.top) : LC.bottom - vh;
    if (!cam.inited) { cam.x = tx; cam.y = ty; cam.inited = true; }
    cam.x += (tx - cam.x) * A.ease * 2;
    cam.y += (ty - cam.y) * A.ease;
  }

  // 휠: 사용자 결정 2026-10-20 — 카메라 줌 (휠이 우선, manualMs 동안 쓰지 않으면 자동으로)
  function wheel(dy) {
    var A = G.DATA.art.camera;
    var z = (cam.manualZ != null ? cam.manualZ : cam.z) * (dy > 0 ? 0.9 : 1.1);
    cam.manualZ = Math.max(A.minZoom, Math.min(A.maxZoom, z));
    cam.manualMs = A.manualMs;
  }
  function resetCamera() { cam.inited = false; cam.manualZ = null; cam.manualMs = 0; }

  function toWorld(sx, sy) { return { x: sx / cam.z + cam.x, y: sy / cam.z + cam.y }; }
  function toScreen(wx, wy) { return { x: (wx - cam.x) * cam.z, y: (wy - cam.y) * cam.z }; }

  function poly(ctx, verts) {
    ctx.beginPath(); ctx.moveTo(verts[0].x, verts[0].y);
    for (var i = 1; i < verts.length; i++) ctx.lineTo(verts[i].x, verts[i].y);
    ctx.closePath();
  }
  function path(ctx, pts) {
    ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
  }

  // 배경 (레벨 툴도 사용)
  function drawBackground(ctx, name, camX, w, h) {
    w = w || V.w; h = h || V.h;
    ctx.fillStyle = C.paper;
    ctx.fillRect(0, 0, w, h);
    var bg = name && name !== 'none' && G.Assets.get(name);
    if (bg) {
      var bw = bg.width * h / bg.height;
      var off = ((camX * G.DATA.art.bgParallax) % bw + bw) % bw;
      for (var x = -off; x < w; x += bw) ctx.drawImage(bg, x, 0, bw, h);
      return;
    }
    if (!specks) specks = makeSpecks();
    ctx.fillStyle = 'rgba(43,33,24,0.08)';
    var off2 = ((camX * 0.5) % 4000 + 4000) % 4000;
    for (var i = 0; i < specks.length; i++) {
      var s = specks[i], sx = s.x - off2;
      if (sx < -10) sx += 4000;
      if (sx > w + 10) continue;
      ctx.beginPath(); ctx.arc(sx, s.y * h / V.h, s.r, 0, 6.283); ctx.fill();
    }
  }

  // 스테이지 배경 이름: 'world' 면 그 월드의 배경(data.js worlds[].bg), 그림이 아직 없으면 빈 종이 (2차 데모, 2026-10-23)
  function bgName(lv) {
    if (lv.bg !== 'world') return lv.bg;
    var w = G.DATA.worlds.filter(function (q) { return q.id === lv.world; })[0];
    return w && G.Assets.get(w.bg) ? w.bg : 'bg_plain';
  }

  // 시작 구멍 (스케치북을 뚫고 나온 구멍)
  function drawStart(ctx, sx, gy) {
    if (gy == null) return;
    var A = G.DATA.art.startHole, s = A.size, cx = sx, cy = gy - A.up;
    var img = G.Assets.get('start_hole');
    if (img) { ctx.drawImage(img, cx - s / 2, cy - s / 2, s, s); return; }
    var rnd = G.makeRng(7), n = 18, i, a, rr;
    ctx.save();
    ctx.beginPath();
    for (i = 0; i <= n; i++) { a = i / n * 6.283; rr = s * (0.42 + rnd() * 0.08); ctx[i ? 'lineTo' : 'moveTo'](cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.92); }
    ctx.closePath(); ctx.fillStyle = '#FFFDF6'; ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = C.outline; ctx.stroke();
    ctx.beginPath();
    for (i = 0; i <= n; i++) { a = i / n * 6.283; rr = s * (0.30 + rnd() * 0.06); ctx[i ? 'lineTo' : 'moveTo'](cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.92); }
    ctx.closePath(); ctx.fillStyle = '#1E1A22'; ctx.fill(); ctx.stroke();
    ctx.restore();
  }

  // 글자 쓰기: 줄바꿈(\n)이 있으면 여러 줄로 (사용자 요청 2026-10-21: UI 툴에서 엔터로 줄바꿈). 줄 간격 = 글자 크기 × 1.25
  function lineH(ctx) { var m = /(\d+(?:\.\d+)?)px/.exec(ctx.font); return (m ? +m[1] : 16) * 1.25; }
  function say(ctx, text, x, y, stroke) {
    var ls = String(text).split('\n'), h = lineH(ctx);
    for (var i = 0; i < ls.length; i++) ctx[stroke ? 'strokeText' : 'fillText'](ls[i], x, y + i * h);
  }
  function nLines(text) { return String(text).split('\n').length; }

  function mix(a, b, t) { return 'rgb(' + a.map(function (v, i) { return Math.round(v + (b[i] - v) * t); }).join(',') + ')'; }

  // 도착: 검은 잉크병. purity 0~1 만큼 병 전체가 검정 → 하늘색으로 섞여 감 (사용자 결정 2026-10-20)
  //   빈 통 이미지(goal_jar_empty, 안쪽 투명) 뒤에 잉크를 칠하고 통을 위에 그림
  //   색 비율은 G.Game.jarMix (정화 정도보다 빨리 밝아짐, 100% 면 물방울 기본색. 사용자 요청 2026-10-21)
  function drawGoal(ctx, gx, gy, purity) {
    if (gy == null) return;
    var J = G.DATA.art.goalJar, x = gx - 10, y = gy - J.h, w = J.w, h = J.h;
    var bx = x + w * 0.12, bw = w * 0.76, by = y + h * 0.2, bh = h * 0.78;
    ctx.save();
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(bx, by, bw, bh, 26); else ctx.rect(bx, by, bw, bh);
    var t = G.Rules.jarMix(purity, G.DATA.goalEnter.jarCurve);
    ctx.fillStyle = mix(C.jarDark, C.jarClear, t);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.fillRect(bx + 12, by + 14, 8, bh * 0.55);
    var empty = G.Assets.get('goal_jar_empty'), dark = G.Assets.get('goal_jar_dark');
    if (empty) ctx.drawImage(empty, x, y, w, h);
    if (dark && empty) {                           // 검은 잉크병 이미지가 정화된 만큼 옅어짐 (아래 하늘색 잉크가 드러남)
      ctx.globalAlpha = 1 - t;
      ctx.drawImage(dark, x, y, w, h);
      ctx.globalAlpha = 1;
    }
    else {
      ctx.lineWidth = 4; ctx.strokeStyle = C.outline; ctx.stroke();
      ctx.fillStyle = '#C9A26B';
      ctx.fillRect(x + w * 0.06, y + h * 0.1, w * 0.88, h * 0.1); ctx.strokeRect(x + w * 0.06, y + h * 0.1, w * 0.88, h * 0.1);
    }
    ctx.restore();
  }

  // 지우개 (사용자 요청 2026-10-20: 벽이 아니라 진짜 지우개가 문지르며 다가오게). 그림이 없으면 예전 eraser_edge / 점선
  //   본체는 게임 시간(정지 중엔 멈춤)으로 위아래로 문지르고, 가루는 화면에만 있는 효과(물리 없음)
  var crumbs = [], lastRun = 0, crumbAcc = 0;
  function drawEraser(ctx, game) {
    var E = G.DATA.art.eraser, ex = game.eraserX, top = cam.y - 50, vh = V.h / cam.z, bottom = cam.y + vh + 50;
    var body = G.Assets.get('eraser_body'), smudge = G.Assets.get('eraser_smudge');
    var dt = game.runMs - lastRun; lastRun = game.runMs;
    if (dt < 0 || dt > 200) { dt = 0; crumbs = []; }          // 새 판이거나 오래 멈췄다 돌아오면 가루 비움
    if (ex < cam.x - 300) { crumbs = []; return; }
    // 지운 자리: 흰 종이
    ctx.fillStyle = '#FFFFFF';
    if (ex > cam.x - 10) ctx.fillRect(cam.x - 10, top, ex - cam.x + 10, bottom - top);
    if (!body) {                                    // 그림이 없을 때: 예전 가장자리 그림
      var img = G.Assets.get('eraser_edge');
      if (img) { var eh = bottom - top, ew = img.width * eh / img.height * 0.6; ctx.drawImage(img, ex - ew * 0.75, top, ew, eh); }
      else { ctx.strokeStyle = 'rgba(43,33,24,0.25)'; ctx.lineWidth = 3; ctx.setLineDash([6, 8]); ctx.beginPath(); ctx.moveTo(ex, top); ctx.lineTo(ex, bottom); ctx.stroke(); ctx.setLineDash([]); }
      return;
    }
    // 경계 띠: 왼쪽 흰색이 지운 자리와 이어지고 오른쪽으로 문지른 자국이 옅어짐. 세로로 반복
    if (smudge) {
      var sw = E.smudgeW, sh = smudge.height * sw / smudge.width, sx = ex - sw * 0.35;
      for (var y = Math.floor(top / sh) * sh; y < bottom; y += sh) ctx.drawImage(smudge, sx, y, sw, sh);
    }
    // 본체: 닳은 아래 모서리가 경계 앞 땅(없으면 화면 아래쪽)까지 내려왔다 올라가며 문지름
    var bh = vh * E.bodyH, bw = body.width * bh / body.height, ph = game.runMs / E.rubMs * Math.PI * 2;
    var gTop = G.Level.groundTopAt(game.level.data, ex + 30), base = gTop == null ? cam.y + vh * 0.8 : Math.min(gTop, cam.y + vh * 0.95);
    var cornerY = base - Math.abs(Math.sin(ph)) * vh * E.rubAmp * 2, tilt = Math.sin(ph * 2) * 0.05;
    // 가루: 문지르는 동안 경계에서 오른쪽 위로 튀어 나가 떨어짐 (게임 시간 기준)
    var parts = [G.Assets.get('eraser_crumb_1'), G.Assets.get('eraser_crumb_2'), G.Assets.get('eraser_crumb_3')].filter(Boolean);
    if (parts.length && dt > 0) {
      crumbAcc += dt;
      while (crumbAcc >= E.crumbMs) {
        crumbAcc -= E.crumbMs;
        var rnd = Math.random;
        crumbs.push({ x: ex + 6, y: cornerY - rnd() * 30, vx: 1.5 + rnd() * 3.5, vy: -2 - rnd() * 3, a: rnd() * 6.28, va: (rnd() - 0.5) * 0.3,
          s: E.crumb[0] + rnd() * (E.crumb[1] - E.crumb[0]), img: parts[Math.floor(rnd() * parts.length)], life: E.crumbLife });
      }
    }
    var k = dt / 16.7;
    crumbs = crumbs.filter(function (c) {
      c.life -= dt; c.x += c.vx * k; c.y += c.vy * k; c.vy += 0.25 * k; c.vx *= Math.pow(0.98, k); c.a += c.va * k;
      return c.life > 0;
    });
    ctx.save();
    ctx.translate(ex, cornerY); ctx.rotate(tilt);
    ctx.drawImage(body, -bw * 0.97, -bh * 0.85, bw, bh);   // 그림 오른쪽 아래(닳은 모서리)가 경계에
    ctx.restore();
    crumbs.forEach(function (c) {
      ctx.save(); ctx.globalAlpha = Math.min(1, c.life / 400); ctx.translate(c.x, c.y); ctx.rotate(c.a);
      ctx.drawImage(c.img, -c.s / 2, -c.s / 2, c.s, c.s); ctx.restore();
    });
  }

  // 물감 선 + 색각 보조 무늬 (검정=없음, 빨강=점, 파랑=화살, 노랑=X, 초록=위 화살)
  function drawInkLine(ctx, pts, color, pending) {
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.lineWidth = color === 'yellow' ? G.DATA.ink.yellowCut * 2 : G.DATA.ink.thickness;   // 노랑은 지우는 폭 그대로 (칠한 부분이 지워짐)
    ctx.strokeStyle = C[color] || C.ink;
    ctx.setLineDash(pending ? [14, 10] : []);
    path(ctx, pts); ctx.stroke();
    ctx.setLineDash([]);
    if (pending || color === 'black') return;
    var gap = 22, acc = gap / 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.fillStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 2;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i], dx = b.x - a.x, dy = b.y - a.y, len = Math.sqrt(dx * dx + dy * dy);
      if (!len) continue;
      var ux = dx / len, uy = dy / len;
      while (acc <= len) {
        var x = a.x + ux * acc, y = a.y + uy * acc;
        ctx.beginPath();
        if (color === 'red') { ctx.arc(x, y, 2, 0, 6.283); ctx.fill(); }
        else if (color === 'blue') { ctx.moveTo(x - ux * 3 - uy * 3, y - uy * 3 + ux * 3); ctx.lineTo(x + ux * 2, y + uy * 2); ctx.lineTo(x - ux * 3 + uy * 3, y - uy * 3 - ux * 3); ctx.stroke(); }
        else if (color === 'yellow') { ctx.moveTo(x - 3, y - 3); ctx.lineTo(x + 3, y + 3); ctx.moveTo(x + 3, y - 3); ctx.lineTo(x - 3, y + 3); ctx.stroke(); }
        else { ctx.moveTo(x - 3, y + 2); ctx.lineTo(x, y - 3); ctx.lineTo(x + 3, y + 2); ctx.stroke(); }
        acc += gap;
      }
      acc -= len;
    }
  }

  // 물방울 그림: 주인공·작은 물방울 같은 그림, 크기만 다름. 대열·붙는 중인 물방울은 위치를 직접 옮기므로 옮긴 거리로 속도를 봄
  function dropVel(d) { return (d.mode === 'line' || d.mode === 'join') && d.vel ? d.vel : d.body.velocity; }
  // 그림 이름을 고름 (없으면 char_idle). 그림마다 바라보는 방향이 달라 art.charFace 로 진행 방향에 맞춰 뒤집음 (사용자 요청 2026-10-20)
  function dropImageName(d) {
    var v = dropVel(d), A = G.DATA.art, get = G.Assets.get.bind(G.Assets), n;
    if (!d.grounded && v.y < -A.airVy) n = 'char_jump';
    else if (!d.grounded && v.y > A.airVy) n = 'char_fall';
    else n = Math.abs(v.x) > 0.5 ? 'char_run' : 'char_idle';
    return get(n) ? n : 'char_idle';
  }
  // 물든 그림 (사용자 결정 2026-10-20): 그림 위에 물든 색을 곱하기로 칠하고 그림 모양으로 잘라 냄 (테두리는 어두운 채로)
  var tintCv = null;
  function tinted(img, d) {
    var a = d.tc ? (d.ta || 0) : 0;
    if (a <= 0.01 || typeof document === 'undefined') return img;
    if (!tintCv) tintCv = document.createElement('canvas');
    var w = img.width, h = img.height, x = tintCv.getContext('2d');
    if (tintCv.width !== w || tintCv.height !== h) { tintCv.width = w; tintCv.height = h; }
    x.globalCompositeOperation = 'source-over'; x.globalAlpha = 1; x.clearRect(0, 0, w, h);
    x.drawImage(img, 0, 0);
    x.globalCompositeOperation = 'multiply'; x.globalAlpha = a * 0.9;
    x.fillStyle = 'rgb(' + d.tc.map(Math.round).join(',') + ')'; x.fillRect(0, 0, w, h);
    x.globalCompositeOperation = 'destination-in'; x.globalAlpha = 1; x.drawImage(img, 0, 0);
    x.globalCompositeOperation = 'source-over';
    return tintCv;
  }
  function tintFill(d) {
    var a = d.tc ? (d.ta || 0) : 0;
    return a > 0.01 ? mix(C.jarClear, d.tc, a) : C.player;
  }

  // 걷기 (사용자 요청 2026-10-20: 코드로 걷는 모습): 움직인 거리만큼 걸음 위상이 돌고, 걸음마다 통통 튀고(bob)·좌우로 기울고(sway)·
  //   발이 닿을 때 눌림(squash). 빠르면 걸음이 빨라짐. 수치는 data.js art.walk
  function walkPose(d) {
    var W = G.DATA.art.walk, p = d.body.position, moved = d.lastDraw ? Math.abs(p.x - d.lastDraw.x) : 0;
    d.lastDraw = { x: p.x, y: p.y };
    var walking = d.grounded && moved > 0.2;
    if (walking) d.walkPhase = ((d.walkPhase || 0) + moved / (d.r * W.stride) * Math.PI) % (Math.PI * 2);
    d.walkAmt = Math.max(0, Math.min(1, (d.walkAmt || 0) + (walking ? 0.15 : -0.1)));   // 멈추면 부드럽게 가라앉음
    var ph = d.walkPhase || 0, a = d.walkAmt;
    return {
      bob: -Math.abs(Math.sin(ph)) * d.r * W.bob * a,
      sway: Math.sin(ph) * W.sway * a + W.lean * a * d.dir,
      squash: (1 - Math.abs(Math.sin(ph))) * W.squash * a
    };
  }

  // 잉크병 앞에 줄 선 물방울(제자리에서 통통) + 입구로 뛰어드는 물방울(작아지며 회전)
  function drawGoalDrops(ctx, game) {
    var get = G.Assets.get.bind(G.Assets), A = G.DATA.art;
    function one(d, x, y, sc, rot, name) {
      var img = get(name) || get('char_idle'), r = d.r * sc, face = (A.charFace && A.charFace[name]) || 1;
      ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(face, 1);
      if (img) { var s = r * A.charSize; ctx.drawImage(tinted(img, d), -s / 2, r - s, s, s); }
      else { ctx.beginPath(); ctx.arc(0, 0, r, 0, 6.283); ctx.fillStyle = tintFill(d); ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = C.outline; ctx.stroke(); }
      ctx.restore();
    }
    game.goalQueue.forEach(function (d, k) {
      var hop = Math.abs(Math.sin(game.timeMs / 180 + k)) * d.r * 0.15;
      one(d, d.qx, d.qy - hop, 1, 0, 'char_idle');
    });
    game.entering.forEach(function (d) {
      var p = G.Game.enterPose(game, d);
      one(d, p.x, p.y, p.scale, p.u * 0.8, p.u < 0.5 ? 'char_jump' : 'char_fall');
    });
  }

  // lineLen: 주인공이면 머리 위에 대열 길이 "×N" (사용자 결정 2026-10-20)
  function drawDrop(ctx, d, lineLen) {
    var b = d.body, r = d.r, v = dropVel(d), A = G.DATA.art;
    var stretch = Math.max(-0.25, Math.min(0.25, -v.y * 0.03));
    var pose = walkPose(d), name = dropImageName(d), img = G.Assets.get(name);
    ctx.save();
    ctx.translate(b.position.x, b.position.y + pose.bob);
    ctx.translate(0, r); ctx.rotate(pose.sway); ctx.translate(0, -r);   // 발밑을 축으로 기움
    if (d.join && d.join.t < d.join.wake) {        // 깨어나는 모션: 기지개(위로 늘었다 줄기) + 좌우 흔들기
      var k = d.join.t / d.join.wake;
      ctx.translate(0, r); ctx.rotate(Math.sin(k * Math.PI * 4) * 0.22 * (1 - k)); ctx.translate(0, -r);
      stretch = Math.sin(k * Math.PI) * 0.25;
    }
    stretch -= pose.squash;
    var face = (A.charFace && A.charFace[name]) || 1;   // 그림이 왼쪽을 보면 -1
    ctx.translate(0, r); ctx.scale((1 - stretch * 0.6) * d.dir * face, 1 + stretch); ctx.translate(0, -r);
    if (img) { var s = r * G.DATA.art.charSize; ctx.drawImage(tinted(img, d), -s / 2, r - s, s, s); }
    else {
      ctx.beginPath(); ctx.arc(0, 0, r, 0, 6.283); ctx.fillStyle = tintFill(d); ctx.fill();
      ctx.lineWidth = d.hero ? 4 : 2.5; ctx.strokeStyle = C.outline; ctx.stroke();
      ctx.fillStyle = C.outline;
      ctx.beginPath(); ctx.arc(r * 0.15, -r * 0.2, r * 0.15, 0, 6.283); ctx.arc(r * 0.6, -r * 0.2, r * 0.15, 0, 6.283); ctx.fill();
    }
    ctx.restore();
    if (d.hero) {                                  // 주인공 표시: 머리 위 작은 왕관 점
      ctx.fillStyle = C.star; ctx.strokeStyle = C.outline; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(b.position.x, b.position.y - r * 2.2, 5, 0, 6.283); ctx.fill(); ctx.stroke();
      if (lineLen) {
        var lt = G.T('hud.lineLen', { n: lineLen });
        ctx.font = G.TF('lineLenSize', true); ctx.textAlign = 'center'; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(255,253,246,0.95)';
        say(ctx, lt, b.position.x, b.position.y - r * 2.2 - 12, true);
        ctx.fillStyle = G.TS('textColor'); say(ctx, lt, b.position.x, b.position.y - r * 2.2 - 12);
        ctx.textAlign = 'left';
      }
    }
  }

  function drawWorld(ctx, game, debug) {
    ctx.save();
    ctx.scale(cam.z, cam.z);
    ctx.translate(-cam.x, -cam.y);
    var lv = game.level.data;
    lv.props.forEach(function (p) { if (p.type === 'deco' || p.type === 'text' || p.type === 'hint') G.Props.draw(ctx, p); });
    G.Props.drawGrounds(ctx, lv.ground);
    lv.props.forEach(function (p) { var d = G.Props.def(p.type); if (d && d.solid && p.type !== 'crystal') G.Props.draw(ctx, p); });
    game.level.crystals.forEach(function (c) { G.Props.drawCrystal(ctx, c); });
    game.fallen.forEach(function (f) {             // 잘려 떨어진 배치된 선 조각
      ctx.save(); ctx.translate(f.body.position.x, f.body.position.y); ctx.rotate(f.body.angle);
      G.Props.drawCrystal(ctx, { x: -f.w / 2, y: -f.h / 2, w: f.w, h: f.h }); ctx.restore();
    });
    drawStart(ctx, lv.start.x, lv.start.y);
    drawGoal(ctx, lv.goal.x, lv.goal.y, jarShown);
    game.level.items.forEach(function (it) { if (!it.got) G.Props.draw(ctx, it.prop); });
    game.level.sleepers.forEach(function (sl) { if (sl.state === 'sleep') G.Props.draw(ctx, sl.prop); });   // 돌려 놓았으면 돌려서

    game.lines.forEach(function (ln) {
      ctx.globalAlpha = ln.active ? 1 : 0.5;
      drawInkLine(ctx, G.Draw.worldPts(ln), ln.color, !ln.active);
    });
    ctx.globalAlpha = 1;
    if (game.stroke && game.stroke.pts.length > 1) {
      ctx.globalAlpha = 0.6; drawInkLine(ctx, game.stroke.pts, game.stroke.color, true); ctx.globalAlpha = 1;
    }
    drawProjectiles(ctx, game);
    G.Game.walking(game).forEach(function (d) { if (!d.hero) drawDrop(ctx, d); });
    if (game.hero.state === 'walk') drawDrop(ctx, game.hero, game.level.data.drops.follow ? game.line.length : 0);
    drawGoalDrops(ctx, game);
    drawEraser(ctx, game);
    drawFx(ctx, game);                             // 지워지는 순간 효과가 흰 종이 위에 보이게 지우개 다음에

    if (debug.showBoxes) {
      ctx.lineWidth = 1.5 / cam.z; ctx.strokeStyle = '#ff00cc';
      G.Physics.allBodies(game.engine).forEach(function (b) {
        (b.parts.length > 1 ? b.parts.slice(1) : [b]).forEach(function (q) { poly(ctx, q.vertices); ctx.stroke(); });
      });
    }
    ctx.restore();
  }

  // 투사체 (사용자 결정 2026-10-22): 흰 그림(proj_white)을 투사체 색으로 물들임(곱하기). 없으면 보라색 proj 를 회색으로 바꿔 물들임,
  //   그것도 없으면 그 색 가시 공. 그림·색마다 한 번만 만들어 둠
  //   lines: 선만 있는 그림(fx_proj_pop)은 곱하면 어두워져 색이 안 보임 → 선을 그 색으로 덮어 칠함 (2026-10-22 이미지 확인)
  //   검정은 곱하면 얼굴이 묻혀서 진한 회색(projTint)으로 곱함
  var tintCache = {};
  function tintImage(white, fallback, color, lines) {
    var img = G.Assets.get(white), gray = false;
    if (!img) { img = G.Assets.get(fallback); gray = true; }
    if (!img || typeof document === 'undefined') return img;
    var key = (gray ? fallback : white) + ':' + color;
    if (tintCache[key] && tintCache[key].src === img) return tintCache[key].cv;
    var cv = document.createElement('canvas'), x = cv.getContext('2d'), col = C[color] || C.ink;
    cv.width = img.width; cv.height = img.height;
    if (gray) x.filter = 'grayscale(1) brightness(1.5)';   // 원래 색을 빼고 밝게 → 색을 곱함
    x.drawImage(img, 0, 0); x.filter = 'none';
    if (lines) {
      x.globalCompositeOperation = 'source-atop'; x.globalAlpha = 0.85; x.fillStyle = col; x.fillRect(0, 0, cv.width, cv.height);
      tintCache[key] = { src: img, cv: cv };
      return cv;
    }
    x.globalCompositeOperation = 'multiply'; x.fillStyle = G.DATA.art.projTint[color] || col; x.fillRect(0, 0, cv.width, cv.height);
    x.globalCompositeOperation = 'destination-in'; x.drawImage(img, 0, 0);
    tintCache[key] = { src: img, cv: cv };
    return cv;
  }
  function drawProjectiles(ctx, game) {
    var r = G.DATA.projectile.radius;
    game.projs.forEach(function (q) {
      var img = tintImage('proj_white', 'proj', q.color);
      if (img) { ctx.drawImage(img, q.x - r * 1.6, q.y - r * 1.6, r * 3.2, r * 3.2); return; }
      ctx.beginPath();
      for (var i = 0; i < 16; i++) {
        var a = i / 16 * 6.283, rr = i % 2 ? r * 0.75 : r * 1.15;
        ctx[i ? 'lineTo' : 'moveTo'](q.x + Math.cos(a) * rr, q.y + Math.sin(a) * rr);
      }
      ctx.closePath(); ctx.fillStyle = C[q.color] || C.ink; ctx.fill();
      ctx.lineWidth = 2.5; ctx.strokeStyle = C.outline; ctx.stroke();
    });
  }

  // 효과: 별 반짝(깨어남·아이템), 착지 먼지, 튕김·가속, 흡수, 빨아들임·자름, 투사체 터짐
  function drawFx(ctx, game) {
    var F = G.DATA.art.fx;
    game.fx.forEach(function (f) {
      var t, img, k, i;
      if (f.type === 'suck' || f.type === 'cut') {
        t = (game.timeMs - f.t) / 350;
        if (t < 0 || t >= 1) return;
        ctx.save(); ctx.globalAlpha = 1 - t; ctx.setLineDash([4, 6]);
        ctx.lineWidth = (f.type === 'cut' ? G.DATA.ink.yellowCut * 2 : G.DATA.ink.thickness) * (1 - t); ctx.strokeStyle = f.type === 'cut' ? C.yellow : (C[f.color] || C.ink);
        path(ctx, f.pts); ctx.stroke(); ctx.restore();
        return;
      }
      if (f.type === 'erasePuff') {                 // 지우개에 지워지는 순간 (화면 시간): 가루 퍼짐 + 물방울은 지워진 얼굴이 흐려짐
        t = (Date.now() - f.real) / G.DATA.art.eraser.puffMs;
        if (t < 0 || t >= 1) return;
        img = G.Assets.get('fx_erase_puff');
        ctx.save();
        if (!f.line) {
          var face = G.Assets.get('char_erased');
          if (face) { var fs = f.r * G.DATA.art.charSize; ctx.globalAlpha = 1 - t; ctx.drawImage(face, f.x - fs / 2, f.y + f.r - fs, fs, fs); }
        }
        k = f.r * (3 + t * 3);
        ctx.globalAlpha = 1 - t * t;
        if (img) ctx.drawImage(img, f.x - k / 2, f.y - k / 2, k, k);
        else { ctx.strokeStyle = 'rgba(43,33,24,0.5)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(f.x, f.y, k / 2, 0, 6.283); ctx.stroke(); }
        ctx.restore();
        return;
      }
      if (f.type === 'absorb') {
        var lv = game.level.data, gy = lv.goal.y;
        t = fxAge(game, f) / ABSORB_MS;
        img = G.Assets.get('fx_absorb');
        if (t < 0 || t >= 1) return;
        ctx.save(); ctx.globalAlpha = 1 - t;
        if (img) { k = 90 + t * 50; ctx.drawImage(img, f.x - k / 2, gy - G.DATA.art.goalJar.h * 0.8 - k / 2, k, k); }
        else { ctx.strokeStyle = C.blue; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(f.x, gy - 120, 20 + t * 40, 0, 6.283); ctx.stroke(); }
        ctx.restore();
        return;
      }
      if (f.type === 'block') {                     // 투사체가 막히거나 맞은 자리: 투사체 색으로 물든 fx_proj_pop (없으면 fx_block), 그것도 없으면 그 색 고리
        t = (game.timeMs - f.t) / F.inkMs;
        if (t < 0 || t >= 1) return;
        img = G.Assets.get('fx_proj_pop') ? tintImage('fx_proj_pop', null, f.color, true) : G.Assets.get('fx_block');
        ctx.save(); ctx.globalAlpha = 1 - t * t;
        if (img) { k = 50 + t * 40; ctx.drawImage(img, f.x - k / 2, f.y - k / 2, k, k); }
        else { ctx.strokeStyle = C[f.color] || C.ink; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(f.x, f.y, 10 + t * 22, 0, 6.283); ctx.stroke(); }
        ctx.restore();
        return;
      }
      if (f.type === 'bounce' || f.type === 'boost') {
        t = (game.timeMs - f.t) / F.inkMs;
        if (t < 0 || t >= 1) return;
        img = G.Assets.get('fx_' + f.type);
        ctx.save(); ctx.globalAlpha = 1 - t * t;
        if (img) { ctx.translate(f.x, f.y); if (f.dir < 0) ctx.scale(-1, 1); ctx.drawImage(img, -45, -40, 90, 45); ctx.restore(); return; }
        ctx.lineWidth = 3; ctx.lineCap = 'round'; k = 10 + t * 18;
        ctx.strokeStyle = f.type === 'bounce' ? C.red : C.blue;
        for (i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(f.x + i * 9, f.y - 4); ctx.lineTo(f.x + i * 16, f.y - 4 - k); ctx.stroke(); }
        ctx.restore();
        return;
      }
      var star = f.type === 'star';
      img = G.Assets.get(star ? 'fx_star_pop' : 'fx_land');
      t = (game.timeMs - f.t) / (star ? F.starPopMs : F.landMs);
      if (!img || t < 0 || t >= 1) return;
      ctx.save(); ctx.globalAlpha = 1 - t * t;
      if (star) { var s = 60 + t * 60; ctx.drawImage(img, f.x - s / 2, f.y - s / 2, s, s); }
      else { var w = 70 + t * 50, h = w / 2; ctx.drawImage(img, f.x - w / 2, f.y - h * 0.75, w, h); }
      ctx.restore();
    });
  }

  // 화면 밖 물방울: 가장자리 화살표 (사용자 결정 2026-10-20). 주인공은 노란 화살표
  function drawArrows(ctx, game) {
    var img = G.Assets.get('ui_arrow'), pad = 26, top = G.TS('hudH') + 14, bottom = V.h - 96;
    G.Game.walking(game).forEach(function (d) {
      var p = toScreen(d.body.position.x, d.body.position.y);
      if (p.x >= 0 && p.x <= V.w && p.y >= G.TS('hudH') && p.y <= V.h) return;
      var cx = Math.max(pad, Math.min(V.w - pad, p.x)), cy = Math.max(top, Math.min(bottom, p.y));
      var a = Math.atan2(p.y - cy, p.x - cx), s = d.hero ? 18 : 12;
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(a);
      if (img) ctx.drawImage(img, -s, -s, s * 2, s * 2);
      else {
        ctx.beginPath(); ctx.moveTo(s, 0); ctx.lineTo(-s * 0.7, -s * 0.75); ctx.lineTo(-s * 0.7, s * 0.75); ctx.closePath();
        ctx.fillStyle = d.hero ? C.star : C.player; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = C.outline; ctx.stroke();
      }
      ctx.restore();
    });
  }

  // 위 막대 (글자·크기·위치는 uitext.js, 사용자 요청 2026-10-21). 잉크·정지 무제한이면 "무제한"·"∞"
  function drawHUD(ctx, game) {
    var S = G.TS, H = S('hudH'), y1 = H - 21, y2 = H - 8, gy = (H - 56) / 2, lv = game.level.data, ink = S('textColor');
    ctx.fillStyle = S('hudBg');
    ctx.fillRect(0, 0, V.w, H);
    ctx.strokeStyle = C.outline; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, H); ctx.lineTo(V.w, H); ctx.stroke();

    var ix = S('inkX');
    ctx.fillStyle = ink; ctx.font = G.TF('hudLabelSize', true);
    say(ctx, G.T('hud.ink'), ix, y1);
    var gx = ix + ctx.measureText(G.T('hud.ink')).width + 14, gw = S('inkGaugeW'), ratio = lv.infInk ? 1 : Math.max(0, game.ink / game.inkMax);
    var frame = G.Assets.get('ui_gauge_frame');
    ctx.fillStyle = ratio > 0 ? 'rgba(43,33,24,0.85)' : '#999';
    if (frame) { ctx.fillRect(gx + 4, gy + 15, (gw - 8) * ratio, 26); ctx.drawImage(frame, gx - 6, gy + 7, gw + 12, 44); }
    else { ctx.strokeRect(gx, gy + 18, gw, 22); ctx.fillRect(gx + 2, gy + 20, (gw - 4) * ratio, 18); }
    ctx.fillStyle = ink; ctx.font = G.TF('hudValueSize');
    var inkTxt = lv.infInk ? G.T('hud.inkInf') : Math.round(game.ink) + ' / ' + game.inkMax;
    say(ctx, inkTxt, gx + gw + 10, y1);

    var sx0 = Math.max(S('stopX'), gx + gw + 10 + ctx.measureText(inkTxt).width + 20);   // 잉크 글자가 길어지면 겹치지 않게 밀림
    ctx.font = G.TF('hudLabelSize', true);
    say(ctx, G.T('hud.stop'), sx0, y1);
    var stopImg = G.Assets.get('ui_stop_on'), first = sx0 + ctx.measureText(G.T('hud.stop')).width + 28, nStop = lv.infStops ? 1 : game.stops.max;
    for (var i = 0; i < nStop; i++) {
      var on = lv.infStops || i < game.stops.left, cx = first + i * 34;
      if (stopImg) { ctx.globalAlpha = on ? 1 : 0.22; ctx.drawImage(stopImg, cx - 16, gy + 12, 32, 32); ctx.globalAlpha = 1; continue; }
      ctx.beginPath(); ctx.arc(cx, gy + 29, 12, 0, 6.283);
      ctx.fillStyle = on ? C.star : 'rgba(43,33,24,0.12)'; ctx.fill();
      ctx.lineWidth = 2; ctx.strokeStyle = C.outline; ctx.stroke();
    }
    if (lv.infStops) { ctx.fillStyle = ink; ctx.font = G.TF('hudLabelSize', true); say(ctx, G.T('hud.stopInf'), first + 22, y1); }

    // 물방울: 걷는 수 · 도착 · 잠든 수 / 정화
    var walking = G.Game.walking(game).length, sleeping = game.level.sleepers.filter(function (s) { return s.state === 'sleep'; }).length;
    var px = first + 10 + Math.max(3, nStop) * 34;
    ctx.fillStyle = ink; ctx.font = G.TF('hudHomeSize', true);
    say(ctx, G.T('hud.home', { rescued: game.rescued, total: game.total }), px, y1 - 5);
    ctx.font = G.TF('hudSmallSize');
    if (lv.drops.follow) {                         // 대열 · 이탈(혼자 걷는 중) · 잠듦 · 잃음 (사용자 결정 2026-10-20)
      var alone = G.Game.walking(game).filter(function (d) { return d.mode === 'free'; }).length;
      say(ctx, G.T('hud.lineInfo', { line: game.line.length, alone: alone, sleep: sleeping, lost: game.lost }), px, y2);
    } else say(ctx, G.T('hud.walkInfo', { walk: walking, sleep: sleeping, lost: game.lost }), px, y2);

    // 오른쪽: 이번 판에 주운 별 (사용자 결정 2026-10-20) + 스테이지 이름·시간·정화
    var sx = V.w - 22 - 26 * Math.max(0, game.starsTotal - 1);
    drawSpeaker(ctx, soundRect(game));
    for (var k = 0; k < game.starsTotal; k++) drawStarIcon(ctx, sx + k * 26 - 4, gy + 20, 11, k < game.starKeys.length);
    ctx.textAlign = 'right'; ctx.font = G.TF('hudSmallSize'); ctx.fillStyle = ink;
    say(ctx, G.T('hud.stage', { name: lv.name, attempt: game.attempt, time: (game.timeMs / 1000).toFixed(1), purity: Math.round(G.Game.purity(game) * 100) }), V.w - 20, y2);
    ctx.textAlign = 'left';
  }

  // 소리 켬/끔 스피커 (사용자 결정 2026-10-22): 위 막대 오른쪽, 별 아이콘 왼쪽. 누르거나 M 키
  var lastStars = 3;
  function soundRect(game) {
    if (game) lastStars = game.starsTotal;
    var H = G.TS('hudH'), s = 30, x = V.w - 22 - 26 * Math.max(0, lastStars - 1) - 4 - 11 - 18 - s;
    return { x: x, y: (H - 56) / 2 + 20 - s / 2, w: s, h: s };
  }
  function soundAt(sx, sy) { var r = soundRect(); return sx >= r.x - 4 && sx <= r.x + r.w + 4 && sy >= r.y - 4 && sy <= r.y + r.h + 4; }
  function drawSpeaker(ctx, r) {
    var on = !(G.Sound && G.Sound.isMuted()), x = r.x, y = r.y, s = r.w, hot = hoverPt && soundAt(hoverPt.x, hoverPt.y);
    ctx.save();
    ctx.strokeStyle = C.outline; ctx.fillStyle = hot ? '#FFE9A8' : 'rgba(255,253,246,0.9)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x + s * 0.12, y + s * 0.38); ctx.lineTo(x + s * 0.3, y + s * 0.38); ctx.lineTo(x + s * 0.52, y + s * 0.16);
    ctx.lineTo(x + s * 0.52, y + s * 0.84); ctx.lineTo(x + s * 0.3, y + s * 0.62); ctx.lineTo(x + s * 0.12, y + s * 0.62); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.lineCap = 'round';
    if (on) {
      ctx.beginPath(); ctx.arc(x + s * 0.55, y + s * 0.5, s * 0.17, -0.9, 0.9); ctx.stroke();
      ctx.beginPath(); ctx.arc(x + s * 0.55, y + s * 0.5, s * 0.32, -0.9, 0.9); ctx.stroke();
    } else {
      ctx.strokeStyle = C.red;
      ctx.beginPath(); ctx.moveTo(x + s * 0.64, y + s * 0.34); ctx.lineTo(x + s * 0.92, y + s * 0.66); ctx.moveTo(x + s * 0.92, y + s * 0.34); ctx.lineTo(x + s * 0.64, y + s * 0.66); ctx.stroke();
    }
    ctx.restore();
  }

  // 스킵 버튼: 주인공이 도착하면 화면 위 가운데 (사용자 결정 2026-10-20)
  function skipRect() { var w = G.TS('skipW'); return { x: V.w / 2 - w / 2, y: G.TS('skipY'), w: w, h: 44 }; }
  function drawSkip(ctx, game) {
    if (!G.Game.canSkip(game)) return;
    var r = skipRect(), all = game.total + 1;        // 끝내면: 들어간 + 줄 선(곧 들어갈) 물방울
    var purity = game.rescued + (game.heroIn ? 1 : 0) + game.goalQueue.length + game.entering.length;
    ctx.fillStyle = 'rgba(255,253,246,0.95)'; ctx.strokeStyle = C.outline; ctx.lineWidth = 3;
    ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(r.x, r.y, r.w, r.h, 10); else ctx.rect(r.x, r.y, r.w, r.h);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = G.TS('textColor'); ctx.font = G.TF('skipSize', true); ctx.textAlign = 'center';
    say(ctx, G.T('skip.button', { n: purity, all: all }), V.w / 2, r.y + 28);
    ctx.textAlign = 'left';
  }
  function skipAt(sx, sy) { var r = skipRect(); return sx >= r.x && sx <= r.x + r.w && sy >= r.y && sy <= r.y + r.h; }

  // 아래 5색 병 선반 (병 클릭 / 숫자 키 1~5)
  function shelfSlots() {
    var S = G.DATA.art.shelf;
    return G.DATA.inks.order.map(function (c, i) {
      return { color: c, key: i + 1, x: S.x + i * S.slot, y: V.h - S.h, w: S.slot - 6, h: S.h };
    });
  }
  function inkAt(sx, sy) {
    var hit = null;
    shelfSlots().forEach(function (b) { if (sx >= b.x && sx <= b.x + b.w && sy >= b.y && sy <= b.y + b.h) hit = b.color; });
    return hit;
  }
  function drawShelf(ctx, game) {
    var S = G.DATA.art.shelf, slots = shelfSlots(), allowed = game.level.data.inks, ink = G.TS('textColor');
    var shelfW = S.x * 2 + slots.length * S.slot - 6, shelfImg = G.Assets.get('ui_shelf');
    if (shelfImg) ctx.drawImage(shelfImg, 0, V.h - 30, shelfW + 10, 30);
    else { ctx.fillStyle = '#B07A45'; ctx.fillRect(4, V.h - 16, shelfW, 12); ctx.strokeStyle = C.outline; ctx.lineWidth = 2.5; ctx.strokeRect(4, V.h - 16, shelfW, 12); }
    var sel = G.Assets.get('ink_select');
    slots.forEach(function (b) {
      var on = allowed.indexOf(b.color) >= 0, picked = game.color === b.color;
      var img = G.Assets.get('ink_' + b.color), bw = S.bottle * 0.75, bh = S.bottle;
      var cx = b.x + b.w / 2, by = V.h - 16 - bh;
      if (picked) {
        if (sel) ctx.drawImage(sel, cx - bw * 0.75, by - 10, bw * 1.5, bh + 20);
        else { ctx.fillStyle = 'rgba(245,197,24,0.4)'; ctx.fillRect(cx - bw * 0.7, by - 6, bw * 1.4, bh + 8); }
      }
      ctx.save(); ctx.globalAlpha = on ? 1 : 0.25;
      if (img) ctx.drawImage(img, cx - bw / 2, by, bw, bh);
      else {
        ctx.fillStyle = C[b.color]; ctx.strokeStyle = C.outline; ctx.lineWidth = 3;
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(cx - bw / 2, by + bh * 0.25, bw, bh * 0.75, 8); else ctx.rect(cx - bw / 2, by + bh * 0.25, bw, bh * 0.75);
        ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#C9A26B'; ctx.fillRect(cx - bw * 0.2, by + bh * 0.08, bw * 0.4, bh * 0.17); ctx.strokeRect(cx - bw * 0.2, by + bh * 0.08, bw * 0.4, bh * 0.17);
      }
      ctx.restore();
      ctx.fillStyle = on ? ink : 'rgba(43,33,24,0.35)'; ctx.font = 'bold 14px ' + G.TS('font'); ctx.textAlign = 'center';
      say(ctx, on ? String(b.key) : G.T('shelf.locked'), cx, by - 4);
      ctx.textAlign = 'left';
    });
    var cur = G.DATA.inks[game.color];
    ctx.fillStyle = ink; ctx.font = G.TF('shelfNameSize', true);
    say(ctx, cur ? cur.name : '', shelfW + 12, V.h - 40);
    ctx.font = G.TF('shelfHelpSize'); ctx.fillStyle = 'rgba(43,33,24,0.6)';
    say(ctx, G.T('shelf.help'), shelfW + 12, V.h - 20);
  }

  function drawStopOverlay(ctx, game) {
    if (!game.stopped) return;
    var H = G.TS('hudH'), col = G.TS('stopColor');
    ctx.fillStyle = C.stopTint;
    ctx.fillRect(0, H, V.w, V.h - H);
    ctx.strokeStyle = col; ctx.lineWidth = 6;
    ctx.strokeRect(3, H + 3, V.w - 6, V.h - H - 6);
    ctx.fillStyle = col; ctx.font = G.TF('stopBannerSize', true); ctx.textAlign = 'center';
    say(ctx, G.T('stop.banner'), V.w / 2, G.TS('stopBannerY'));
    ctx.textAlign = 'left';
  }

  function drawMessages(ctx, game) {
    ctx.textAlign = 'center'; ctx.font = G.TF('msgSize', true);
    var y = G.TS('msgY');
    game.messages.forEach(function (m) {            // 여러 줄 문구는 그만큼 아래로
      ctx.globalAlpha = Math.min(1, m.ms / 400);
      ctx.fillStyle = G.TS('msgColor');
      say(ctx, m.text, V.w / 2, y);
      y += nLines(m.text) * lineH(ctx) + 8;
    });
    ctx.globalAlpha = 1; ctx.textAlign = 'left';
  }

  // 별 하나 (on = 주움). 그림이 있으면 그림, 없으면 도형
  function drawStarIcon(ctx, x, y, r, on) {
    var img = G.Assets.get(on ? 'star_full' : 'star_empty');
    if (img) { ctx.drawImage(img, x - r, y - r, r * 2, r * 2); return; }
    G.Props.drawStarShape(ctx, x, y, r);
    if (on) { ctx.fillStyle = C.star; ctx.fill(); }
    ctx.lineWidth = 2; ctx.strokeStyle = on ? C.outline : 'rgba(43,33,24,0.35)'; ctx.stroke();
  }

  // 효과가 나온 뒤 지난 시간. 게임 시간 기준이지만 판이 끝나면(게임 시간이 멈춤) 실제 시간으로 이어서 →
  //   마지막 물방울의 흡수 효과가 클리어 순간 굳지 않고 끝까지 재생됨 (사용자 요청 2026-10-21)
  var ABSORB_MS = 500;
  function fxAge(game, f) { return game.timeMs - f.t + (game.status === 'run' ? 0 : Math.max(0, Date.now() - game.finishedAt)); }
  function absorbPlaying(game) { return game.fx.some(function (f) { return f.type === 'absorb' && fxAge(game, f) < ABSORB_MS; }); }

  // 클리어 결과 창은 잉크병이 다 밝아지고 흡수 효과(fx_absorb)가 다 끝난 뒤 resultDelayMs 더 기다렸다가
  //   (사용자 요청 2026-10-20: 정화되는 모습을 1초 더 / 2026-10-21: 흡수 효과가 다 나왔다 사라진 다음)
  var jarDoneAt = 0;
  function resultReady(game) {
    if (game.status !== 'clear') return true;
    if (absorbPlaying(game)) { jarDoneAt = 0; return false; }
    if (jarShown < G.Game.purity(game) - 1e-6) { jarDoneAt = 0; return false; }
    if (!jarDoneAt) jarDoneAt = Date.now();
    return Date.now() - jarDoneAt >= G.DATA.goalEnter.resultDelayMs;
  }

  // 월드 첫 판 안내 카드 (2차 데모, 사용자 결정 2026-10-23): 새 물감 그림(tut_wN, 없으면 코드로 그린 선 견본) + 설명. 클릭·스페이스로 닫음
  function drawTutorial(ctx, game) {
    var w = game.tutorial, wd = G.DATA.worlds[w - 1], S = G.TS, cw = S('tutW'), ch = S('tutH'), x = (V.w - cw) / 2, y = (V.h - ch) / 2;
    ctx.save();
    ctx.fillStyle = 'rgba(43,33,24,0.45)'; ctx.fillRect(0, 0, V.w, V.h);
    ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, cw, ch, 18); else ctx.rect(x, y, cw, ch);
    ctx.fillStyle = '#FFFDF6'; ctx.fill(); ctx.lineWidth = 5; ctx.strokeStyle = C.outline; ctx.stroke();
    ctx.fillStyle = wd.color; ctx.fillRect(x + 24, y + 22, cw - 48, 10);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = 'bold ' + S('tutTitleSize') + 'px ' + S('font'); ctx.fillStyle = wd.color === '#2B2118' ? C.outline : wd.color;
    ctx.fillText(G.T('tut.w' + w + '.title'), V.w / 2, y + 70);
    var pic = G.Assets.get('tut_w' + w), ph = 160, pw = ph * 16 / 9, py = y + 100;
    if (pic) ctx.drawImage(pic, V.w / 2 - pw / 2, py, pw, ph);
    else {                                         // 그림이 없을 때: 땅 두 덩이 + 새 색 선 견본 + 물방울
      var gx = V.w / 2 - pw / 2, gy = py + ph - 40, col = C[G.DATA.inks.order[Math.min(w, 5) - 1]];
      ctx.fillStyle = C.ground; ctx.fillRect(gx, gy, pw * 0.38, 40); ctx.fillRect(gx + pw * 0.62, gy, pw * 0.38, 40);
      ctx.strokeStyle = C.outline; ctx.lineWidth = 3; ctx.strokeRect(gx, gy, pw * 0.38, 40); ctx.strokeRect(gx + pw * 0.62, gy, pw * 0.38, 40);
      ctx.strokeStyle = col; ctx.lineWidth = 10; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(gx + pw * 0.3, gy - 5); ctx.quadraticCurveTo(gx + pw * 0.5, gy - 30 * (w === 3 ? 2 : 0.4), gx + pw * 0.7, gy - 5); ctx.stroke();
      var t = (Date.now() / 1600) % 1, hx = gx + 30 + t * (pw - 60), hy = gy - 22 - (hx > gx + pw * 0.3 && hx < gx + pw * 0.7 ? Math.sin((hx - gx - pw * 0.3) / (pw * 0.4) * Math.PI) * (w === 3 ? 50 : 10) : 0);
      var hero = G.Assets.get('char_run');
      if (hero) ctx.drawImage(hero, hx - 26, hy - 30, 52, 52); else { ctx.fillStyle = '#CDEFF7'; ctx.beginPath(); ctx.arc(hx, hy, 18, 0, 6.283); ctx.fill(); ctx.stroke(); }
    }
    ctx.fillStyle = S('textColor'); ctx.font = S('tutBodySize') + 'px ' + S('font');
    G.T('tut.w' + w + '.body').split('\n').forEach(function (l, i) { ctx.fillText(l, V.w / 2, py + ph + 36 + i * S('tutBodySize') * 1.4); });
    ctx.font = S('tutMoreSize') + 'px ' + S('font'); ctx.fillStyle = 'rgba(43,33,24,0.75)';
    ctx.fillText(G.T('tut.w' + w + '.more'), V.w / 2, y + ch - 62);
    ctx.font = 'bold ' + S('tutMoreSize') + 'px ' + S('font'); ctx.fillStyle = S('textColor');
    ctx.fillText(G.T('tut.go'), V.w / 2, y + ch - 30);
    ctx.restore();
  }

  function drawResult(ctx, game) {
    var ink = G.TS('textColor');
    resultShown = false;
    if (game.tutorial) { drawTutorial(ctx, game); return; }
    if (game.status === 'run') { if (game.paused) drawPause(ctx, game); return; }
    if (game.status === 'ready') {
      var ry = G.TS('readyY');
      ctx.textAlign = 'center'; ctx.fillStyle = ink; ctx.font = G.TF('readyTitleSize', true);
      say(ctx, G.T('ready.title'), V.w / 2, ry);
      ctx.font = G.TF('readyHelpSize');
      say(ctx, G.T('ready.help'), V.w / 2, ry + 35);
      ctx.textAlign = 'left';
      return;
    }
    if (!resultReady(game)) return;
    resultShown = true;
    resultParts = [];
    ctx.fillStyle = 'rgba(43,33,24,0.35)';
    ctx.fillRect(0, 0, V.w, V.h);
    var S = G.TS, clear = game.status === 'clear' && game.result;
    drawPanelBg(ctx, panelRect(game));   // 바탕 그림 크기는 uitext.js (사용자 요청 2026-10-21)
    // 결과 창 안의 것은 모두 uitext.js 위치(게임 화면 px)에 그림 (사용자 요청 2026-10-21: UI 툴에서 끌어 옮기기). c = 클리어, f = 실패
    var face = G.Assets.get(game.status === 'fail' ? 'char_erased' : 'char_goal'), p = clear ? 'c' : 'f', fs = S(p + 'FaceSize');
    if (face) {
      ctx.drawImage(face, S(p + 'FaceX'), S(p + 'FaceY'), fs, fs);
      part(p + 'FaceX', p + 'FaceY', S(p + 'FaceX'), S(p + 'FaceY'), fs, fs);
    }
    ctx.textAlign = 'center'; ctx.fillStyle = game.status === 'clear' ? S('clearColor') : S('failColor');
    ctx.font = G.TF('resultTitleSize', true);
    sayPart(ctx, game.status === 'clear' ? G.T('result.clear') : game.failReason, p + 'TitleX', p + 'TitleY');
    ctx.fillStyle = ink;
    if (clear) {                                   // 별 n/3 과 정화 % 를 따로 (사용자 결정 2026-10-20)
      var r = game.result, best = game.best;
      ctx.font = G.TF('resultSize', true);
      sayPart(ctx, G.T('result.stars', { stars: r.stars, total: r.starsTotal }), 'cStarsTextX', 'cStarsTextY');
      var sr = S('cStarSize') / 2, gap = S('cStarGap'), sx = S('cStarsX'), sy = S('cStarsY');   // 별 줄: 가운데 x, y
      for (var k = 0; k < r.starsTotal; k++) drawStarIcon(ctx, sx + (k - (r.starsTotal - 1) / 2) * gap, sy, sr, k < r.stars);
      var rowW = (r.starsTotal - 1) * gap + sr * 2;
      part('cStarsX', 'cStarsY', sx - rowW / 2, sy - sr, rowW, sr * 2);
      // 정화 막대 (왼쪽 위 x, y)
      var bw = S('cBarW'), bh = S('cBarH'), bx = S('cBarX'), by = S('cBarY');
      ctx.fillStyle = 'rgba(43,33,24,0.12)'; ctx.fillRect(bx, by, bw, bh);
      ctx.fillStyle = mix(C.jarDark, C.jarClear, G.Rules.jarMix(r.purity, G.DATA.goalEnter.jarCurve)); ctx.fillRect(bx, by, bw * r.purity, bh);
      ctx.lineWidth = 2; ctx.strokeStyle = C.outline; ctx.strokeRect(bx, by, bw, bh);
      part('cBarX', 'cBarY', bx, by, bw, bh);
      ctx.fillStyle = ink; ctx.font = G.TF('resultSize', true);
      sayPart(ctx, G.T('result.purity', { purity: Math.round(r.purity * 100), inJar: r.inJar, all: r.all }), 'cPurityX', 'cPurityY');
      ctx.font = G.TF('resultSize');
      sayPart(ctx, G.T('result.time', { time: (r.timeMs / 1000).toFixed(1) }) + (best ? G.T('result.best', { stars: best.stars || 0, total: r.starsTotal,
        purity: Math.round((best.bestPurity || 0) * 100) }) : ''), 'cTimeX', 'cTimeY');
    } else {
      ctx.font = G.TF('resultRetrySize');
      sayPart(ctx, G.T('result.failInfo', { rescued: game.rescued, total: game.total, attempt: game.attempt }), 'fInfoX', 'fInfoY');
      sayPart(ctx, G.T('result.time', { time: (game.timeMs / 1000).toFixed(1) }), 'fTimeX', 'fTimeY');
    }
    resultBtns(game).forEach(function (b) { drawButton(ctx, b); });
    ctx.textAlign = 'left';
  }

  // Esc 일시 정지 창 (사용자 결정 2026-10-21): 결과 창과 같은 바탕·버튼. 제목 + 계속하기 · 다시 하기. 위치·크기는 uitext.js (UI 툴)
  function drawPanelBg(ctx, pr) {
    var panel = G.Assets.get('ui_panel');
    if (panel) ctx.drawImage(panel, pr.x, pr.y, pr.w, pr.h);
    else { ctx.fillStyle = C.paper; ctx.fillRect(pr.x + 40, pr.y + 30, pr.w - 80, pr.h - 60); ctx.strokeStyle = C.outline; ctx.lineWidth = 4; ctx.strokeRect(pr.x + 40, pr.y + 30, pr.w - 80, pr.h - 60); }
  }
  function drawPause(ctx, game) {
    resultShown = true;
    resultParts = [];
    ctx.fillStyle = 'rgba(43,33,24,0.35)';
    ctx.fillRect(0, 0, V.w, V.h);
    drawPanelBg(ctx, panelRect(game));
    ctx.textAlign = 'center'; ctx.fillStyle = G.TS('pauseColor'); ctx.font = G.TF('resultTitleSize', true);
    sayPart(ctx, G.T('pause.title'), 'pauseTitleX', 'pauseTitleY');
    resultBtns(game).forEach(function (b) { drawButton(ctx, b); });
    ctx.textAlign = 'left';
  }

  // 결과 창 안에 그린 것들의 자리 (UI 툴에서 끌어 옮기기용): { keys: [x 이름, y 이름], x, y, w, h }
  var resultParts = [];
  function part(kx, ky, x, y, w, h) { resultParts.push({ keys: [kx, ky], x: x, y: y, w: w, h: h }); }
  // 가운데 맞춤 글자를 (x 이름, y 이름) 자리에 쓰고 자리 기록
  function sayPart(ctx, text, kx, ky) {
    var x = G.TS(kx), y = G.TS(ky), lh = lineH(ctx), w = 0;
    say(ctx, text, x, y);
    String(text).split('\n').forEach(function (l) { w = Math.max(w, ctx.measureText(l).width); });
    part(kx, ky, x - w / 2, y - lh * 0.8, w, lh * nLines(text));
  }

  // 결과 창 바탕 그림(ui_panel) 자리: 화면 가운데, 크기는 클리어·실패 따로 (사용자 요청 2026-10-21)
  function panelRect(game) {
    var k = game.paused ? 'pausePanel' : game.status === 'fail' ? 'failPanel' : 'resultPanel', w = G.TS(k + 'W'), h = G.TS(k + 'H');
    return { x: (V.w - w) / 2, y: (V.h - h) / 2, w: w, h: h };
  }

  // 결과 창 버튼 (사용자 요청 2026-10-21): 다시 하기 · 다음 스테이지(클리어 + 다음이 있을 때). 위치·크기는 uitext.js (UI 툴)
  //   다시 하기 자리는 세 가지 따로: 클리어(retryBtn) · 클리어인데 다음 스테이지 없음(retryAlone) · 실패(failRetry)
  var resultShown = false, hoverPt = null;
  function retryKeys(game) {
    if (game.status === 'fail') return ['failRetryX', 'failRetryY'];
    return game.hasNext ? ['retryBtnX', 'retryBtnY'] : ['retryAloneX', 'retryAloneY'];
  }
  function resultBtns(game) {
    var S = G.TS, w = S('resultBtnW'), h = S('resultBtnH'), next = game.status === 'clear' && game.hasNext, rk = retryKeys(game), out = [];
    // 스테이지 목록 버튼 (2차 데모, 사용자 결정 2026-10-23): 레벨 툴 테스트 플레이(메뉴 없음)에서는 안 보임
    var menu = !(G.app && G.app.testMode);
    if (game.paused) return [
      { act: 'resume', x: S('pauseResumeX'), y: S('pauseResumeY'), w: w, h: h, label: G.T('pause.resume'), keys: ['pauseResumeX', 'pauseResumeY'] },
      { act: 'retry', x: S('pauseRetryX'), y: S('pauseRetryY'), w: w, h: h, label: G.T('pause.retry'), keys: ['pauseRetryX', 'pauseRetryY'] }
    ].concat(menu ? [{ act: 'menu', x: S('pauseMenuX'), y: S('pauseMenuY'), w: w, h: h, label: G.T('pause.menu'), keys: ['pauseMenuX', 'pauseMenuY'] }] : []);
    out.push({ act: 'retry', x: S(rk[0]), y: S(rk[1]), w: w, h: h, label: G.T('result.retry'), keys: rk });
    if (next) out.push({ act: 'next', x: S('nextBtnX'), y: S('nextBtnY'), w: w, h: h, label: G.T('result.next'), keys: ['nextBtnX', 'nextBtnY'] });
    if (menu) {
      var mk = game.status === 'fail' ? ['failMenuX', 'failMenuY'] : ['menuRetryX', 'menuRetryY'];
      out.push({ act: 'menu', x: S(mk[0]), y: S(mk[1]), w: w, h: h, label: G.T('result.menu'), keys: mk });
    }
    return out;
  }
  function drawButton(ctx, b) {
    var hot = hoverPt && hoverPt.x >= b.x && hoverPt.x <= b.x + b.w && hoverPt.y >= b.y && hoverPt.y <= b.y + b.h;
    ctx.save();
    ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(b.x, b.y, b.w, b.h, 10); else ctx.rect(b.x, b.y, b.w, b.h);
    ctx.fillStyle = hot ? G.TS('resultBtnHot') : G.TS('resultBtnBg'); ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = C.outline; ctx.stroke();
    ctx.fillStyle = G.TS('textColor'); ctx.font = G.TF('resultRetrySize', true); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    var lh = lineH(ctx), n = nLines(b.label);
    say(ctx, b.label, b.x + b.w / 2, b.y + b.h / 2 - (n - 1) * lh / 2);
    ctx.restore();
  }
  // 화면 좌표 → 누른 결과 창·일시 정지 창 버튼 ('retry' / 'next' / 'resume' / 'menu' / null). 창이 보일 때만
  function resultAt(game, sx, sy) {
    if (!resultShown || (game.status !== 'clear' && game.status !== 'fail' && !game.paused)) return null;
    var hit = null;
    resultBtns(game).forEach(function (b) { if (sx >= b.x && sx <= b.x + b.w && sy >= b.y && sy <= b.y + b.h) hit = b.act; });
    return hit;
  }
  function hover(sx, sy) { hoverPt = { x: sx, y: sy }; }
  // UI 툴: 결과 창이 보일 때 버튼 목록·바탕 자리
  function resultLayout(game) { return resultShown ? { btns: resultBtns(game), panel: panelRect(game), parts: resultParts.slice() } : null; }

  // 잉크병 밝기: 들어간 물방울 수(정화)를 향해 서서히 (사용자 요청 2026-10-20: 갑자기 밝아지지 않게). 새 시도면 바로 어둡게
  var jarShown = 0;
  function updateJar(game, dt) {
    var target = G.Game.purity(game), step = G.DATA.goalEnter.jarFadePerSec * dt / 1000;
    if (target < jarShown) jarShown = target;
    else jarShown = Math.min(target, jarShown + step);
  }

  var lastT = 0;
  function render(ctx, game, debug) {
    var now = Date.now(), dt = lastT ? Math.min(100, now - lastT) : 16;
    lastT = now;
    updateCamera(game, dt);
    updateJar(game, dt);
    drawBackground(ctx, bgName(game.level.data), cam.x);
    drawWorld(ctx, game, debug);
    drawArrows(ctx, game);
    drawStopOverlay(ctx, game);
    drawHUD(ctx, game);
    drawSkip(ctx, game);
    drawShelf(ctx, game);
    drawMessages(ctx, game);
    drawResult(ctx, game);
  }

  return { render: render, toWorld: toWorld, toScreen: toScreen, cam: cam, wheel: wheel, resetCamera: resetCamera,
           drawBackground: drawBackground, bgName: bgName, drawGoal: drawGoal, drawStart: drawStart,
           inkAt: inkAt, skipAt: skipAt, resultAt: resultAt, soundAt: soundAt, hover: hover, resultLayout: resultLayout, drawInkLine: drawInkLine };
})();
